tag @s remove tmf.off.fast_paths
function tmf:menu/cat/movement
