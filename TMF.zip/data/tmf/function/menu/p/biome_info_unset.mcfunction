tag @s remove tmf.off.biome_info
function tmf:menu/cat/info
